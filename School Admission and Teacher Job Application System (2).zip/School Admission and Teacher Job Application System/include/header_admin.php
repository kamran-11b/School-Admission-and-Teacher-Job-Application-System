 <nav class="navbar navbar-expand-lg navbar-dark sticky-top" style="padding:15px;background-color:#094d2a;">
     <div class="container">
         <a class="navbar-brand" href="#"><i>Sofir Uddin High School</i></a>
         <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
             <span class="navbar-toggler-icon"></span>
         </button>

         <div class="collapse navbar-collapse" id="navbarResponsive">
             <ul class="navbar-nav ml-auto">
                 <li style="margin-right:10px" class="nav-item"><a class="nav-link" href="app_student.php">Application Student</a></li>
                 <li style="margin-right:10px" class="nav-item"><a class="nav-link" href="app_teacher.php">Application Teacher</a></li>
                 <li style="margin-right:10px" class="nav-item"><a class="nav-link" href="notice_admin.php">Notice</a></li>
                 <li style="margin-right:10px" class="nav-item"><a class="nav-link" href="admin.php">Admin</a></li>
                 <li style="margin-right:0px" class="nav-item"> <a class="nav-link" href="logout.php" >Log out</a></li>
             </ul>
         </div>
     </div>
 </nav>
